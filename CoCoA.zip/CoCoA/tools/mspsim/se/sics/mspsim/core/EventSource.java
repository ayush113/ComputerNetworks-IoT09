package se.sics.mspsim.core;

public interface EventSource {
  public String getName();
}
